import exp2
global arr
print(arr)