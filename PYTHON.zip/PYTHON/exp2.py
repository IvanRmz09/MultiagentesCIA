global arr
arr = [1, 2, 3, 4]